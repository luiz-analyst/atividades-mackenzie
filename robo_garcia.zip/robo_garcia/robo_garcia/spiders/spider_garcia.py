import scrapy
import os
import pathlib
import csv 


class SpiderGarciaSpider(scrapy.Spider):
    name = 'spider_garcia'
    #allowed_domains = ['del.com']
    start_urls = ['https://www.gazetadopovo.com.br/vozes/alexandre-garcia/']

    def parse(self, response):
        for page in response.css(".has-image"):
            link = page.css(".trigger-gtm::attr(href)").get()
            text_page = f"https://www.gazetadopovo.com.br{link}"
            print(text_page)
            yield scrapy.Request(text_page, callback=self.parse_text)
        
        next_page = response.css(".pagination").css(".next-pagination::attr(href)").get()
        if next_page is not None:
            yield scrapy.Request(next_page, callback=self.parse)
    
    def parse_text(self,response):
        content = ""
        for artigos in response.css(".tpl-post"):
            title = artigos.css(".c-content-header .post-title").css("h1::text").get()
            x = artigos.css("#paywall-google p::text").getall()
            del(x[len(x)-2])
            del(x[len(x)-1])
            for line in x:
                content = content + "".join(line.strip()) + "\n"
            post = {"author":"Alexandre Garcia","title":title.strip().encode('utf-8'),"content":content.encode('utf-8')}
            
            with open('artigos_garcia.csv', 'a', newline='', encoding="utf-8")  as output_file:
             dict_writer = csv.DictWriter(output_file, post.keys())            
             dict_writer.writerows([post]) 
            yield post